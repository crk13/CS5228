"""Package generated predictions/model separately from source and raw data."""

import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/trees"
DESTINATION = ROOT / "deliverables"


def main():
    DESTINATION.mkdir(exist_ok=True)
    best = json.loads((OUT / "best_model.json").read_text(encoding="utf-8"))
    paths = sorted((OUT / "experiments").glob("*/validation_predictions.csv"))
    paths += [ROOT / best["submission"], OUT / "models/best_tree.joblib"]
    entries = []
    archive = DESTINATION / "yaqi_tree_results.zip"
    with ZipFile(archive, "w", compression=ZIP_DEFLATED, compresslevel=6) as bundle:
        for path in paths:
            content = path.read_bytes()
            relative = path.relative_to(ROOT).as_posix()
            bundle.writestr(relative, content)
            entries.append({"path": relative, "bytes": len(content),
                            "sha256": hashlib.sha256(content).hexdigest()})
    manifest = {"archive": archive.name, "archive_bytes": archive.stat().st_size,
                "archive_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
                "best_model": best["name"], "seed": best["seed"],
                "validation_rmse": best["validation"], "mean_rmse": best["mean_rmse"],
                "contains_raw_or_cleaned_datasets": False, "files": entries}
    (DESTINATION / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"Packaged {len(entries)} files; archive size: {archive.stat().st_size / 1024**2:.2f} MiB")


if __name__ == "__main__":
    main()
